#include "CCharter.h"

void CCharter::prepareDemoGamePlay(CGamePlay &gp)
{
	for (auto np : gpModule.players)
	{
		np.enableBot = true;
		gp.players.push_back(np);
	}
}

void CCharter::preRender()
{
	bool kfor = CEngine::engine().getKey(GLFW_KEY_UP), kback = CEngine::engine().getKey(GLFW_KEY_DOWN);

	if (kfor || kback)
	{
		if (!bForwardBackwardK)
		{
			if (kfor)
				atMusicTime += 0.5;
			else{
				if (atMusicTime > 0.0) atMusicTime -= 0.5;
				
				if (atMusicTime < 0.0)
					atMusicTime = 0.0;
			}
			bForwardBackwardK = true;
		}
	}
	else
	{
		bForwardBackwardK = false;
	}

	for (auto &p : gpModule.players)
	{
		p.musicRunningTime = atMusicTime;

		auto &notes = p.Notes;
		auto &gNotes = p.Notes.gNotes;
		auto &engine = CEngine::engine();

		while (true)
		{
			if (notes.plusPos > 0)
			{
				auto pp = notes.plusPos - 1;

				auto &plPos = notes.gPlus[notes.plusPos];

				if ((plPos.time + plPos.lTime) > (atMusicTime - 2.0))
				{
					notes.plusPos = pp;
				}
			}

			if (notes.notePos > 0)
			{
				auto np = notes.notePos - 1;

				auto &gnote = gNotes[np];

				if ((gnote.time + gnote.lTime) > (atMusicTime - 2.0))
				{
					notes.notePos = np;
				}
				else
				{
					break;
				}
			}
			else
			{
				break;
			}
		}
	}



	gpModule.update();

}

void CCharter::render()
{
	gpModule.render();
}

void CCharter::renderAll()
{
	preRender();
	render();
}

CCharter::CCharter()
{
	bForwardBackwardK = false;
	atMusicTime = 0.0;
	gpModule.players.push_back(CPlayer("guitar charter"));
	gpModule.bIsACharterGP = true;

	std::string song = GPPGame::GuitarPP().songToLoad;
	//module.players[0].loadSongOnlyChart(song);
	//module.players[1].loadSong(song);
	gpModule.players.back().loadSong(song);
	gpModule.bRenderHUD = false;

	for (auto &b : fretKeys)
	{
		b = false;
	}
}

