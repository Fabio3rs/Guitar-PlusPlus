WindowWidth = 800
WindowHeight = 600
FullScreen = false

--customTitle = "teste"

setConfigs()
doNotRunAgain()
