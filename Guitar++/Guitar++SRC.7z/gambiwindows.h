#pragma once
#ifndef _GAMBIWINDOWS_h_
#define _GAMBIWINDOWS_h_

void startGambiarras();


#endif