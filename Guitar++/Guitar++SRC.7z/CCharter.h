#pragma once
#ifndef _GPP_CCHARTER_H_
#define _GPP_CCHARTER_H_

#include "CPlayer.h"
#include "CEngine.h"
#include "CGamePlay.h"
#include "GPPGame.h"

class CCharter
{
	CGamePlay gpModule;
	double atMusicTime;
	bool bForwardBackwardK;
	bool fretKeys[5];

public:
	void prepareDemoGamePlay(CGamePlay &gp);

	void preRender();
	void render();
	void renderAll();

	CCharter();
};


#endif